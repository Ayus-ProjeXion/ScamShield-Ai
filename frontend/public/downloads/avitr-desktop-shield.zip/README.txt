==============================================================================
∀VITR AI — Real-Time Windows Desktop Shield Companion (v4.2)
==============================================================================

WHAT IT DOES:
Protects you from cyber scams in real-time. Whenever you press Ctrl+C inside 
WhatsApp Desktop, Telegram, SMS, or any browser tab, ∀VITR AI immediately checks 
the copied text and pops up a native Windows notification if it is a scam!

HOW TO USE (2 Simple Steps):
1. Make sure Python 3.8+ is installed on your computer.
2. Double-click 'start-companion.bat'.
3. That's it! It runs quietly in the background.

SECURITY & PRIVACY GUARANTEE:
• 100% Read-Only: Only inspects clipboard text when YOU press Ctrl+C.
• Zero-Knowledge Privacy: Never saves or uploads passwords, bank details, or chats.
• Zero Malware / Safe Execution: Fully open-source, audited, with zero tracking.
• Local Offline AI: Can detect extortion and fraud entirely offline without network delay.

To stop it at any time, simply close the terminal window or press Ctrl+C.
==============================================================================
